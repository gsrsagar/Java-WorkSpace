package com.mphasis.stormreaper.exceptions;

public class BusinessException {

}
