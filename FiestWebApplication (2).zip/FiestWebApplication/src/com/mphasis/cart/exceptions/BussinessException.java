package com.mphasis.cart.exceptions;

public class BussinessException extends Exception {
	
	public BussinessException(String message)
	{
		 super(message);
	}

}
