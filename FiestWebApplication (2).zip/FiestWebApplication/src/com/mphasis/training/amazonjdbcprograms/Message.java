package com.mphasis.training.amazonjdbcprograms;

import java.util.ListResourceBundle;

public class Message extends ListResourceBundle{

	@Override
	protected Object[][] getContents() {
		// TODO Auto-generated method stub
		return contents;
	}
	static final Object[][] contents= { {"snack.puri","panipuri"},{"snacks.bhel","bhelpuri"},{"snacks.masala","masalapuri"}};

}
