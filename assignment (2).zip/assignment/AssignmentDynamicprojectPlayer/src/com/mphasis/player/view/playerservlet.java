package com.mphasis.player.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mphasis.player.beans.Player;
import com.mphasis.player.bo.PlayerBo;
import com.mphasis.player.bo.PlayerBoImp;
import com.mphasis.player.dao.PlayerDao;
import com.mphasis.player.dao.PlayerDaoImp;

/**
 * Servlet implementation class playerservlet
 */
@WebServlet("/list")
public class playerservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */PlayerBo playerBo;
    public playerservlet() {
       
        playerBo=new PlayerBoImp();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//Player p=new Player(); 
	try {	List<Player> players =new ArrayList<>();
		players=playerBo.getAllPlayers();
		out.print("<table border='1'>");
		out.print("<tr>"+"<th>playerid</th>"+"<th>Playername</th>"+"<th>Gender</th>"+"<th>Contact</th>"+"<th>Email</th>"+"<th>Teamaname</th>"+"<th>Age</th>"+"<th>Date od birth</th>"+"<th>Score</th>"); 
		//Player player;
		for( Player player:players)
		{   out.print("<tr>"); 
			out.print("<td>"+player.getPid()+"</td>");
			out.print("<td>"+player.getPname()+"</td>");
			out.print("<td>"+player.getGender()+"</td>");
			out.print("<td>"+player.getContact()+"</td>");
			out.print("<td>"+player.getEmail()+"</td>");
			out.print("<td>"+player.getTeamname()+"</td>");
			out.print("<td>"+player.getAge()+"</td>");
			out.print("<td>"+player.getDob()+"</td>");
			out.print("<td>"+player.getScore()+"</td>");	 
		   out.print("</tr>");
		}
		out.print("</table>");
	RequestDispatcher rs=request.getRequestDispatcher("menu.html");
	 rs.include(request,response);
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
