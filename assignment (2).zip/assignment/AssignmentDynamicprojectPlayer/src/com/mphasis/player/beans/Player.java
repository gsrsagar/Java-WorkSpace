package com.mphasis.player.beans;

import java.util.Date;

public class Player {

	private  int pid;
	private String pname;
	private String gender;
	private long contact;
  	private String email;
  	private String teamname;
  	private int age;
  	private Date dob;
  	private long score;
	
  	
  	
  	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTeamname() {
		return teamname;
	}
	public void setTeamname(String teamname) {
		this.teamname = teamname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public long getScore() {
		return score;
	}
	public void setScore(long score) {
		this.score = score;
	}
	
	
	
	@Override
	public String toString() {
		return "Player [pid=" + pid + ", pname=" + pname + ", gender=" + gender + ", contact=" + contact + ", email="
				+ email + ", teamname=" + teamname + ", age=" + age + ", dob=" + dob + ", score=" + score + "]";
	}
	public Player(int pid, String pname, String gender, long contact, String email, String teamname, int age, Date dob,
			long score) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.gender = gender;
		this.contact = contact;
		this.email = email;
		this.teamname = teamname;
		this.age = age;
		this.dob = dob;
		this.score = score;
	}
	
	public Player() {
		super();
		// TODO Auto-generated constructor stub
	}
  	
  	
	
}
