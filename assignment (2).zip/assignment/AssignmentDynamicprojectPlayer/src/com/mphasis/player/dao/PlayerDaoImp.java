package com.mphasis.player.dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mphasis.player.beans.Player;
import com.mphasis.player.dbutil.DbUtil;

public class PlayerDaoImp implements PlayerDao {

 Connection con;
	
 public PlayerDaoImp() {
		con=DbUtil.openConnection();
		
		
	}

	@Override
	public  List<Player> getAllPlayers() {
		List<Player> players=new ArrayList<Player>();
		try {
			String sql="select * from player";
		 PreparedStatement pst=con.prepareStatement(sql);	 
		 ResultSet re=pst.executeQuery();
		 while(re.next())
		 {   Player p=new Player(); 
			 p.setPid(re.getInt(1));
			 p.setPname(re.getString(2));
			 p.setGender(re.getString(3));
			 p.setContact(re.getLong(4));
			 p.setEmail(re.getString(5));
			 p.setTeamname(re.getString(6));
			 p.setAge(re.getInt(7));
			 p.setDob(re.getDate(8));
			 p.setScore(re.getLong(9));
    		 players.add(p);
		 }
		 	 
		}catch(Exception e) {
			 e.printStackTrace();
		}	
			return players;
	}

	@Override
	public int getPlayerById() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getPlayerByName() {
		// TODO Auto-generated method stub
		return 0;
	}

}
