package com.mphasis.player.dao;

import java.util.List;

import com.mphasis.player.beans.Player;

public interface PlayerDao {
	
	public List<Player> getAllPlayers();
	public int getPlayerById();
	public int getPlayerByName();
	

}
