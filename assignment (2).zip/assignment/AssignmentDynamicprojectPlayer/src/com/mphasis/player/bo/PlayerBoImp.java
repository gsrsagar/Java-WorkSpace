package com.mphasis.player.bo;

import java.util.ArrayList;
import java.util.List;

import com.mphasis.player.beans.Player;
import com.mphasis.player.dao.PlayerDao;
import com.mphasis.player.dao.PlayerDaoImp;

public class PlayerBoImp implements PlayerBo {
 
	PlayerDao playerDao=new PlayerDaoImp();
	
	@Override
	public List<Player> getAllPlayers() {
		
		List<Player> players=new ArrayList<Player>();
		players=playerDao.getAllPlayers();
		
		return players;
	}

	@Override
	public int getPlayerById() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getPlayerByName() {
		// TODO Auto-generated method stub
		return 0;
	}

}
