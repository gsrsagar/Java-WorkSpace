package com.mphasis.player.bo;

import java.util.List;

import com.mphasis.player.beans.Player;

public interface PlayerBo {
	public List<Player> getAllPlayers();
	public int getPlayerById();
	public int getPlayerByName();
}
