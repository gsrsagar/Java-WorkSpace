package com.traning.mphasis;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class FileHandlingSample {
	
	
	public static void main(String args[]) throws IOException
	{
		FileOutputStream fos =new FileOutputStream("abc.txt");
		
		BufferedOutputStream bos=new BufferedOutputStream(fos);
		String s1="Mohith is very talkative";
		//fos.write(56);
		bos.write(s1.getBytes());
		bos.close();
		fos.close();
		
		FileInputStream fis=new FileInputStream("abc.txt");
		BufferedInputStream bis=new BufferedInputStream(fis);
		int i;
		//System.out.println((char)fis.read());
		//System.out.println((char)fis.read());
		while((i=bis.read())!=-1)
		{
			System.out.print((char)i);		
	    }
		fis.close();
	}

}
