package Java8.features;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.StringJoiner;
import java.util.function.Predicate;
import java.util.stream.Collectors;

//import org.omg.Messaging.SyncScopeHelper;

public class StringJoinerDemo {
	
	public static void main(String args[])
{
	 ArrayList<String> filist=new ArrayList<>();
	  filist.add("predicate");
	  filist.add("Function");
	  filist.add("BiFunction");
	  filist.add("Bipredicate");
	  filist.add("Consumer");
	  filist.add("Supplier");
	  
	  filist.forEach(System.out::println);
	  filist.forEach((a)->System.out.println(a));
	  
	  StringJoiner st=new StringJoiner("-","{ ","}");
	  
	  st.setEmptyValue("st is empty");
	  System.out.println(st.length());
	  
	  
	  st.add(filist.get(4)).add(filist.get(5));               // adding more than one parameter
	  st.add("ss");
	  st.add("mm");
	  st.add("as");
	  st.add("st");
	  System.out.println(st);
	  
	  StringJoiner st1=new StringJoiner("-","{ ","}");
	  st.add(filist.get(1)).add(filist.get(0));
	  
	  st.add("mm");
	  st.add("as");
	  st1.merge(st);
	  System.out.println(st1);
	  
	  
	  String[] sta=new String[] {"pune","Banglore","Chennai"};      //to convert array in to list we have the asList() method
	  List<String> locations= Arrays.asList(sta);
	   Collections.sort(locations);
	   locations.forEach(System.out::println);
	   System.out.println("------------------------------");
	   System.out.println("Sort according to the length");
	   Collections.sort(locations,(s1,s2)->s1.length()-s2.length());   //to sort according to the length
	   
	   locations.forEach(System.out::println);
	   
	   
	   List<Integer> lis=new ArrayList<Integer>();
	   
	   lis.add(11);
	   lis.add(12);
	   lis.add(13);
	   lis.add(14);
	   lis.add(11);
	   lis.add(11);
	   lis.add(11);
	   
	     Predicate<Integer> f1=n->(n%2)==0;
	     
	     lis.forEach((n)->System.out.println((n%2==0)?n:0));
	     
	     
	     List<Integer> l2=lis.stream().filter(i-> (i%2)==0).collect(Collectors.toList());
	     System.out.println("-------------------------");
	     l2.forEach(System.out::println);
     
	     
	     
	   
	   
	  
}

}
