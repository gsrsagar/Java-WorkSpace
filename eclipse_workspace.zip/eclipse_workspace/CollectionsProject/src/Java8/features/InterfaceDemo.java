package Java8.features;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;

@FunctionalInterface
 interface Calc {
	 public int add(int a,int b);
	 //public void add1(int a,int b);
	 public static void sub(int a ,int b)
	 {
		 System.out.println(a-b);
	 }

}

 public class InterfaceDemo{
  public static void main(String args[])
  {
	  Calc c1=(a,b)->(a+b);
	  System.out.println(c1.add(23, 57));
	  System.out.println(c1.add(56, 57));
	  System.out.println(c1.add(1, 57));
	  System.out.println(c1.add(21, 57));
	  System.out.println(c1.add(33, 57));
	  System.out.println(c1.add(20, 57));
	  
	  
	  //Pre-defined FI's
	  //Predicate-- one argument
	  //Function--two arguments --(one argument as value , and one argument is return type);
	  //Bifunction --three arguments(two arguments , and one return value);
	  
	  
	  System.out.println("-------------------------------");
	  Predicate<Integer> f1=n->(n%2)==0;
	   System.out.println(f1.test(21));
	   System.out.println(f1.test(21));
	   System.out.println(f1.test(21));
	   System.out.println("-------------------------------");
	   
	   Function<Integer,Integer> f2 =n->n*n;
	   System.out.println(f2.apply(21));
	   System.out.println(f2.apply(21));
	   System.out.println(f2.apply(21));
	   System.out.println("-------------------------------");
	   
	   BiFunction<Integer, Integer,Integer> f3= (n,p)->n*p;
	   
	   System.out.println(f2.apply(21));
	   System.out.println(f2.apply(21));
	   System.out.println(f2.apply(21));
	   System.out.println("---------------------------------");
	   
	   BiFunction<Integer,Integer,Integer> f4=(num1,num2)->(num1>num2? num1:num2);
	   System.out.println( f4.apply(2,5));
	   
	   
	   
	   
	  
	  
	  
	  
  }
 }


