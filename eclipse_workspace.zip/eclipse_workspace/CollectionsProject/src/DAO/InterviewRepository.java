package DAO;

import java.util.ArrayList;
import java.util.List;

public class InterviewRepository {
	
	List<Candidate> candidates=null;
	  public InterviewRepository()
	  {   
		  
		  candidates=new ArrayList<>();
	      candidates.add(new Candidate("venakt","java","Guntur",2));
	      candidates.add(new Candidate("Sagar","java","Nellore",4));
	      candidates.add(new Candidate("murali","java","Nellore",2));
	      candidates.add(new Candidate("rohit","SQL","Nellore",0));
	      candidates.add(new Candidate("Afshaan","java","kurnool",2));
	      
	      
	      
	      
		  
	  }
	  
	  public List<Candidate> getAllCandidates()
	  {
		   return candidates;
	  }
	  
	  public void addCandidate(Candidate c)
	  {
		   candidates.add(c);
	  }
	  public Candidate getCandidate(int index)
	  {
		  Candidate c=candidates.get(index);
		  return c;
		  
	  }
	  public void deleteCandidate(int index)
	  {
		  candidates.remove(index);
		  
	  }
	 
	
	
	
	
	
	

}
