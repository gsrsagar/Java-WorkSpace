package DAO;

import java.util.*;
import java.util.stream.Collectors;

public class CandidateOperations {
	
	
	public static void main(String args[])
	{
		   InterviewRepository repo=new InterviewRepository();
		   List<Candidate> candidates=repo.getAllCandidates();
		  System.out.println("=====================================");
		  for(Candidate c:candidates)
		  {
			   System.out.println(c.getName()+ " "+c.getTechnicalExpertise()+" "+c.getYearsofexp());
			   
		  }
		  
		  System.out.println(" 1.Candiadtes from Indore \n 2.list city and count of candidates \n 3. technical and count \n 4. freshers");
		  
		  System.out.println("---------------------------------------");
		  List<Candidate> indorecan= repo.getAllCandidates().stream().filter((can)->can.getPlace().equals("Indore")).collect(Collectors.toList());
	      
		  System.out.println("----------------2------------------------");
    // city--count means MAP;(key value pairs)
		  
		  Map<String,List<Candidate>> cancount=repo.getAllCandidates().stream().collect(Collectors.groupingBy((can)->can.getPlace()));
		  
		  for(String place:cancount.keySet())
		  {
			  System.out.println(place+" "+cancount.get(place).size());
		  }
		  System.out.println("-----------------3-----------------------");
		  Map<String,List<Candidate>> cancount1=repo.getAllCandidates().stream().collect(Collectors.groupingBy((can)->can.getTechnicalExpertise()));
		  for(String TexhnicalExpertise:cancount1.keySet())
		  {
			  System.out.println(TexhnicalExpertise+" "+cancount1.get(TexhnicalExpertise).size());
		  }
		  System.out.println("-------------------4---------------------");
		 
		  List<Candidate> fresher=repo.getAllCandidates().stream().filter((c)->c.getYearsofexp()==0).collect(Collectors.toList());
		  for(Candidate c:fresher)
		  {
			   System.out.println(c);
		  }
		  System.out.println("--------------------5--------------------");
		  int MaxExp=repo.getAllCandidates().stream().map((can)-> can.getYearsofexp()).max(Integer::compare).get();
		  List<Candidate> senior=repo.getAllCandidates().stream().filter((c)->c.getYearsofexp()==MaxExp).collect(Collectors.toList());
		  
		  for(Candidate c:senior)
		  {
			   System.out.println(c);
		  }
		  
		  
	}

}
