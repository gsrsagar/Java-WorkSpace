package com.mphasis.training.assignmentjava8;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.*;



public class EmployeeRepository {
	


	
	
	//LocalDate doj=LocalDate.of(sc.nextLine());
	List<Employee> employees=null;
	List<Department> departments= null;
	  public EmployeeRepository()
	  {   
		  departments=new ArrayList<>();
		  employees=new ArrayList<>();
           employees.add(new Employee(1,"Bhuma","Pravallika","bhuma.pravallika@mphasis.com",987654321L,"12 Apr 2015","BussinessAssociate",236546D,2368360)) ;
           employees.add(new Employee(2,"Sagar","guvvala","guvvala.sagar@mphasis.com",9494744282L,"10 May 2012","Software",900000D,2368365)) ;
           employees.add(new Employee(3,"Utkarsh","Mishra","utkarsh.mishra@mphasis.com",987654761L,"23 Apr 2013","Engineer",2364246D,2228360)) ;
           employees.add(new Employee(4,"Riya","Bisen","riya,bisan@mphasis.com",983654321L,"22 may 2019","Software",266546D,2868365)) ;
           employees.add(new Employee(5,"Priyanka","abcd","priyanka.abcd@mphasis.com",987653321L,"09 Apr 2011","HumanResource",299546D,2988370)) ;
           employees.add(new Employee(6,"xjdy","uhsdd","xjdy.uhsdd@mphasis.com",987753321L,"25 may 2016","SystemAssociate",236546D,2368360)) ;
           employees.add(new Employee(7,"ghud","iuju","ghud.iujua@mphasis.com",987687321L,"15 Apr 2017","FullStack",236546D,2368365)) ;
	      
	      
           departments.add(new Department(501,"Apps",2368360));
           departments.add(new Department(502,"IT",2368365));
           departments.add(new Department(503,"HR",2368370));
           
           
           
           
           
	      }
	  
	 
	 /*public new Department("Account", 75); 
      Department hr = new Department("HR", 50);
      Department ops = new Department("OP", 25);
      Department tech = new Department("Tech", 150);*/         
	  
	  public List<Employee> getAllEmployees()
	  {
		   return employees;
	  }
	  
	  public void addEmployee(Employee c)
	  {
		   employees.add(c);
	  }
	  public Employee getEmployee(int index)
	  {
		  Employee c=employees.get(index);
		  return c;
		  
	  }
	  public void deleteEmployee(int index)
	  {
		  employees.remove(index);
		  
	  }
	 
	
}	
	
	

	


