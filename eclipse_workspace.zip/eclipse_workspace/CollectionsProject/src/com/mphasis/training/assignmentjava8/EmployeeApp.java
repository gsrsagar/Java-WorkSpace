/**
 * 
 */
package com.mphasis.training.assignmentjava8;

import java.util.List;
import java.util.*;


/**
 * @author guvvala.sagar
 *
 */
public class EmployeeApp {
	
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		EmployeeRepository repository=new EmployeeRepository();
		System.out.println("Welcome to company portal");
		do{
			
			
			 System.out.println("1. Add employee \n 2. Remove \n  3. ViewEmployee \n  4. ViewAll  \n 5. Exit");
			 int choice=sc.nextInt();
			 switch(choice)
			 {
			 
			 case 1:System.out.println("Enter employeeId\nfirstNamr\nlastName\nemail\nphoneNum\ndoj\ndesignation\nsalary\nmanagerId ");
			       repository.addEmployee(new Employee(sc.nextInt(),sc.next(),sc.next(),sc.next(),sc.nextLong(),sc.nextLine(),sc.next(),sc.nextDouble(),sc.nextInt()));
			        System.out.println("Employeeadded");
			        
				    break;
			
			 case 2:  System.out.println("enter the index");
			         repository.deleteEmployee(sc.nextInt());
			         System.out.println("The employee deleted successfully");
				 
				    break;
				    
			 case 3: System.out.println("Enter the index");
			         Employee cl=repository.getEmployee(sc.nextInt());
			         System.out.println(cl.getEmpId()+ " "+cl.getFirstName()+" "+cl.getLastName()+" "+cl.getEmail()+" "+cl.getPhoneNum()+" "+cl.getDoj()+" "+cl.getDesignation()+" "+cl.getSalary()+" "+cl.getManagerId());
			         
				     break;
			 case 4:  System.out.println("List of employees");
			         List<Employee> cans=repository.getAllEmployees();
			         cans.forEach((c)->System.out.println(c));
			         
				    break;
				    
			 case 5: System.out.println("Thank you, you can leave for today ");
			         System.exit(0);
				    break;
			 default :  System.out.println("invalid");
				      
				 
			 }
		}while(true);
	}

}
