package com.mphasis.training.collectionprograms;


import java.util.*;
public class StudentDemo {	
	
	public static void main(String args[])
	{
		List<Student> student1=new ArrayList<Student>();
		
		student1.add(new Student(1,"Sagar",99,22));
		student1.add(new Student(2,"padma",98,22));
		student1.add(new Student(3,"Vinutha",97,22));
		student1.add(new Student(4,"Subbarao",96,20));
		student1.add(new Student(5,"rohit",95,22));
		student1.add(new Student(6,"Supragna",94,22));
		student1.add(new Student(7,"bhuma",93,21));
		student1.add(new Student(8,"Neeraja",92,22));
		student1.add(new Student(9,"ravikiran",91,19));
		student1.add(new Student(10,"Afshaan",90,22));
		System.out.println(student1);
		
		for(Student s:student1)
		{ 
			System.out.println("Student id:"+" "+s.getSid()+" Student name: "+" "+s.getSname()+" "+ "Student age: "+" "+s.getAge()+" Student Marks: "+" "+s.getMarks()); 
		}
		
		System.out.println("1.Students based on Id:  \n 2. based on name :  \n 3. student based on marks: \n 4. Student based on age:");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the choice");
		int choice=sc.nextInt();
	  switch(choice)
	  {
	      case 1: Collections.sort(student1);
	      		for(Student s:student1)
	      		{ 
				System.out.println("Student id:"+" "+s.getSid()+" Student name: "+" "+s.getSname()+" "+ "Student age: "+" "+s.getAge()+" Student Marks: "+" "+s.getMarks()); 
	      		}
	              break;
	      case 2: 
	               
	      		for(Student s:student1)
	      		{ 
	      			System.out.println("Student id:"+" "+s.getSid()+" Student name: "+" "+s.getSname()+" "+ "Student age: "+" "+s.getAge()+" Student Marks: "+" "+s.getMarks()); 
	      		}
                  
	              break;
	       
	      case 3:      Collections.sort(student1,new Comparator() {
	    	       
	    	       

				@Override
				public int compare(Object o1, Object o2) {
					Student s1=(Student)o1;
					 Student s2=(Student)o2;
					 if(s1.getMarks()> s2.getMarks())
	    	    		  return -1;
	    	    	   else if(s1.getMarks()< s2.getMarks())
	    	              return 1;
	    	    	   else
	    	    		   return 0;	} });
	      
	        //Collections.sort(student1,(s1,s2)-> s1.getMarks()-s2.getMarks());
	       
	      
	      /* Collections.sort(student1,new Comparator(){
	      public int compare(Student s1, Student s2) {
	    	  return s1.getMarks()-s2.getMarks();
	      }
	      });*/
	      		for(Student s:student1)
	      			{ 
	      			System.out.println("Student id:"+" "+s.getSid()+" Student name: "+" "+s.getSname()+" "+ "Student age: "+" "+s.getAge()+" Student Marks: "+" "+s.getMarks()); 
	      				}
	      			break;
                  
	      case 4: 
	           
	      
	        
	      			for(Student s:student1)
	      				{ 
	      					System.out.println("Student id:"+" "+s.getSid()+" Student name: "+" "+s.getSname()+" "+ "Student age: "+" "+s.getAge()+" Student Marks: "+" "+s.getMarks()); 
	      				}
	      			
                    break;
	       default: System.out.println("Invalid");       
	              
	  }
	  
	  
		 
		
		
		
	}
	
	
}
