package com.mphasis.training.collectionprograms;

import java.util.*;
public class SetDemo {
	
	public static void main(String args[])
	{
		  Set<String> s1=new TreeSet<>();
		  s1.add("Srujana");  
		  s1.add("Susmitha");
		  s1.add("Supraja");
		  s1.add("Sampoorna");
		  s1.add("Sunandha");
		  s1.add("Sreeja");
		  s1.add("Sheema");
		  s1.add("Sheeri");
		  s1.add("Suchi");
		  s1.add("Supriya");
		  s1.add("Sankeertha");
		  s1.add("sankalpa");
		  s1.add("Sujitha");
		  s1.add("Sulochana");
		  
		  
		  System.out.println(s1);
		  Set<Employee> employee=new TreeSet<>();
		   employee.add(new Employee(1,"sagar","AP"));
		   employee.add(new Employee(2,"asshu","AP"));
		   employee.add(new Employee(3,"vinnu","KA"));
		   employee.add(new Employee(4,"paddu","AP"));
		   for(Employee e:employee)
		   {
			    System.out.println(e.getEmpid()+ " "+e.getEname()+ " "+e.getAddress());
		   }
		   	   
		   
		   
		  
		  
		  
	}

}
