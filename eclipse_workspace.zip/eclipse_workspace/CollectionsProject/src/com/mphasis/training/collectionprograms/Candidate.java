package com.mphasis.training.collectionprograms;

public class Candidate {
	 private String name;
	 private String technicalExpertise;
	 private int yearsofexp;
	 
	 
	public Candidate(String name, String technicalExpertise, int yearsofexp) {
		
		this.name = name;
		this.technicalExpertise = technicalExpertise;
		this.yearsofexp = yearsofexp;
	}
	public String getName() {
		return name;
	}
	
	public String getTechnicalExpertise() {
		return technicalExpertise;
	}
	
	public int getYearsofexp() {
		return yearsofexp;
	}
	
	@Override
	public String toString() {
		return "Candidate [name=" + name + ", technicalExpertise=" + technicalExpertise + ", yearsofexp=" + yearsofexp
				+ "]";
	}
	 
	public Candidate()
	{
	}
	

}
