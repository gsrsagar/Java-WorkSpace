package com.mphasis.training.amazoncartApp;
import com.mphasis.training.amazonjdbcprograms.*;
import com.mphasis.cart.dao.*;

import java.util.*;

import javax.swing.plaf.synth.SynthSeparatorUI;
public class CartApp {
	
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome to the amazon  select the choice \n  1. Register \n 2. Login   ");
	    int choice=sc.nextInt();	
		CartAUserDao dao=new CartAUserImp1();
		Product p2=new Product();
		List<Product> pt=new ArrayList<>();
		ProductdaoImp1 pd=new ProductdaoImp1();
		System.out.println("1. Register  \n 2.Login");
		
		if(choice==1)
		{ 
			 System.out.println("Enter your details");
			 CartAUser user=new CartAUser();
			 System.out.println("enter user id");
			 user.setUserid(sc.nextInt());
			 System.out.println("enter username");
			 user.setUsername(sc.next());
			 System.out.println("enter email");
			 user.setEmail(sc.next());
			 System.out.println("enter password");
			 user.setPassword(sc.next());
			 System.out.println("enter credit card no");
			 user.setCredit(sc.nextLong());
			 System.out.println("enter gender");
			 user.setGender(sc.next());
			 dao.register(user);
			 System.out.println("Registered Successfully");
			
		}
			

					  				
		
			 
		else if(choice==2)
		{  
		    System.out.println("Enter user email and the password");
		    String email=sc.next();
		    String pass=sc.next();
		    CartAUser user = dao.login(email,pass);
		    
		  try {
		    if(email.equals(user.getEmail()) && pass.equals(user.getPassword()))
		    {
		    	 
		    		  System.out.println("Successfully logged on");
		    	  }
		}catch(Exception e) {
			System.out.println("invalid username and password");
		System.exit(0);
		}
		  do
		  { 
				  
			   System.out.println("1.View  all Products \n 2.Add Product \n 3. Update Product \n 4. Delete Product  \n 5. Retrieve Product By ID  \n 6. Retrieve  Product By name \n 7.Logout  ");
			  
			  
			   int op=sc.nextInt();
			 
				  if(op==1)
					{     
					  List<Product> products=pd.getAll();
					  products.forEach((pr)-> System.out.println(pr));
						
					}
				  
				  else if(op==2)
					{   System.out.println("Enter the product details 1. product name \n 2.Product id  \n 3. Cost  \n 4. Qunatity");
					
					     p2.setPname(sc.next());
					     p2.setPid(sc.nextInt());
					     p2.setCost(sc.nextDouble());
					     p2.setQuantity(sc.nextDouble());
					    pd.addProduct(p2);
					    System.out.println("A New product is added");
						
					}
				  else if(op==3)
					{  System.out.println(" Enter the  following details to update the product" );
						System.out.println("1. pid: 2. cost 3. qty");  
					    int j=pd.updateProduct(sc.nextInt(), sc.nextDouble(),sc.nextDouble());
					  if(j>0)
						  System.out.println("Successfully updated the product");
					  else
						  System.out.println("Not possible");
					}
				  
				  else if(op==4)
					{   System.out.println(" Enter the  following details delete product" );
					    System.out.println(" enter product id:");  
					    int j=pd.deleteProduct(sc.nextInt());
					    if(j>0)
					    System.out.println("Successfully deleted the product");
					    else
							  System.out.println("Not possible");
						
					}
				  else if(op==5)
					{  System.out.println("Enter the product id");
					   Product pi= pd.getById(sc.nextInt());
					   System.out.println("product details");
					  System.out.println(pi);
					  System.out.println("Successfully retrieved the product ");
						 
					}
				  else if(op==6)
					{ System.out.println("Enter the product name");
					List<Product> pn=new ArrayList<>();
					   pn= pd.getProductByName(sc.next());
					  
					  System.out.println("product details");
					  System.out.println(pn);
					   System.out.println("Successfully retrieved the product ");
						  
					}
				  else if(op==7)
					{   System.out.println("Successfully logged out");
					 System.exit(0);
					}
				  else
				  {    }	
					 
			  }while(true);
				  				
	}

		  else
		  {
			  System.out.println("bye");
		  }
			  
		
	}
			  
	
}

			  
		 
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
		    
			
		
		
	
	
		
	