package com.mphasis.training.jdbcprograms;


import java.sql.*;
public class JdbcDemo1 
{

	
	public static void main(String args[])throws ClassNotFoundException
	{
	Class.forName("oracle.jdbc.OracleDriver");
    try{
    	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "java166sqlsagar", "sagar");
    
    System.out.println("Database connected");
 
    
   
	Statement st=con.createStatement();
	
	ResultSet rs=st.executeQuery("select * from employee");
	System.out.println("done");
    while(rs.next())
    {
    	System.out.println(rs.getInt(1)+ " "+rs.getString(2)+" "+rs.getDouble("salary"));
    	
    }
  //ResultSet rs1=st.executeQuery("insert  into job values(89,'Testingautomated')");
    //PreparedStatement ps= con.PreparedStatement("insert into employee")
    int i=st.executeUpdate("insert into job values(261,'testingdevelopment')");
    if(i>0)
    {
    	System.out.println("inserted");
    }
    
  ResultSet rs1=st.executeQuery("select * from JOB");
  	
      while(rs1.next())
      {
      	System.out.println(rs1.getInt(1)+" "+rs1.getString(2));
      	
      }
    
    }catch (SQLException e) {
		
	e.printStackTrace();
    }
    
    
}
}

