package Java8.features;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class TimeApiDemo {
	
	 public static void main(String args[])
	 {
		 LocalDate today=LocalDate.now();
		 LocalDate doj=LocalDate.of(2010, 07, 05);
		 
		 Period p=Period.between(doj, today);
		 System.out.println(p);
		 
		 System.out.println("--------------------------");
		 LocalTime l=LocalTime.now();
		 System.out.println(l);
		 
		 System.out.println("--------------------------");
		 
		 LocalDateTime t1=LocalDateTime.now();
		 System.out.println(t1);
		 System.out.println("--------------------------");
		 
		 LocalTime l1=LocalTime.now(ZoneId.of("Asia/Calcutta"));
		 System.out.println(l1);
		 System.out.println("--------------------------");
		 
		 Instant i=Instant.now();
		 System.out.println(i);
		 System.out.println("--------------------------");
		 
		 for(String s:ZoneId.getAvailableZoneIds())
		 {
			  System.out.println(s);

		 
		 }
		 System.out.println("--------------------------");
		 
		 String anotherDate="12 Apr 2017";
		 DateTimeFormatter ft= DateTimeFormatter.ofPattern("dd MMM yyyy");
		 LocalDate lt=LocalDate.parse(anotherDate,ft);
		 System.out.println(lt);
         System.out.println("------------------------------");
		 
		 
	 }
	

}
