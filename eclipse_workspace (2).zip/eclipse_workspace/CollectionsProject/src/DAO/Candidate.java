package DAO;

public class Candidate {
	 private String name;
	 private String technicalExpertise;
	 private String place;
	 
	 
	 public String getPlace() {
		return place;
	}
	

	private int yearsofexp;
	 
	 
	
	public Candidate(String name, String technicalExpertise, String place, int yearsofexp) {
		
		this.name = name;
		this.technicalExpertise = technicalExpertise;
		this.place = place;
		this.yearsofexp = yearsofexp;
	}

	public String getName() {
		return name;
	}
	
	public String getTechnicalExpertise() {
		return technicalExpertise;
	}
	
	public int getYearsofexp() {
		return yearsofexp;
	}
	
	@Override
	public String toString() {
		return "Candidate [name=" + name + ", technicalExpertise=" + technicalExpertise + ", place=" + place
				+ ", yearsofexp=" + yearsofexp + "]";
	}
	 
	//public Candidate()
	//{
	//}
	

}
