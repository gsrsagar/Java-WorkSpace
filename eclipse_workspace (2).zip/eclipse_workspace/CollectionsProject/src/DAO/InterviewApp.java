package DAO;

import java.util.*;

public class InterviewApp {
	
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		InterviewRepository repository=new InterviewRepository();
		System.out.println("Welcome to our app");
		do{
			
			
			 System.out.println("1. Add candidate \n 2. Remove \n  3. ViewCandiadte \n  4. ViewAll  \n 5. Exit");
			 int choice=sc.nextInt();
			 switch(choice)
			 {
			 
			 case 1:System.out.println("Enter name, technical, years of experience ");
			       repository.addCandidate(new Candidate(sc.nextLine(),sc.nextLine(),sc.nextLine(),sc.nextInt()));
			        System.out.println("Candidate added");
			        
				    break;
			
			 case 2:  System.out.println("enter the index");
			         repository.deleteCandidate(sc.nextInt());
			         System.out.println("The person deleted successfully");
				 
				    break;
				    
			 case 3: System.out.println("Enter the index");
			         Candidate cl=repository.getCandidate(sc.nextInt());
			         System.out.println(cl.getName()+ " "+cl.getTechnicalExpertise()+" "+cl.getPlace()+" "+cl.getYearsofexp());
			         
				     break;
			 case 4:  System.out.println("List of candidates");
			         List<Candidate> cans=repository.getAllCandidates();
			         cans.forEach((c)->System.out.println(c.getName()+" "+c.getTechnicalExpertise()+" "+c.getPlace()+"" +c.getYearsofexp()));
			         
				    break;
				    
			 case 5: System.out.println("Thank you, you can leave for today ");
			         System.exit(0);
				    break;
			 default :
				      System.out.println("Invalid");
				 
			 }
		}while(true);
	}

}
