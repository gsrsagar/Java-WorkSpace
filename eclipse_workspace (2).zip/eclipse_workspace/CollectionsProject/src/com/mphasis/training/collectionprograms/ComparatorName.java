package com.mphasis.training.collectionprograms;

import java.util.Comparator;

public class ComparatorName implements Comparator<Employee> {

	@Override
	public int compare(Employee e1, Employee e2) {
		// TODO Auto-generated method stub
		return e1.getEname().compareTo(e2.getEname());
	}

}
