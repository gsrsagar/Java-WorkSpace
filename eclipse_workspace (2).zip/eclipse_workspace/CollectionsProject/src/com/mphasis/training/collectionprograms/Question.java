package com.mphasis.training.collectionprograms;

import java.util.*;
public class Question implements Comparable<Question>{

	 String ques;

	public String getQues() {
		return ques;
	}

	public void setQues(String ques) {
		this.ques = ques;
	}

	public Question(String ques) {
		super();
		this.ques = ques;
	}
	
	public Question()
	{
		
	}

	@Override
	public int compareTo(Question o) {
		return ques.compareTo(o.getQues());
	  	
	}

	/*public int compareTo(Question q)
	{
		 if(ques>)
	}*/
	
}
