package com.mphasis.training.collectionprograms;

public class InterviewRepository {
	
	public static void main(String args[])
	{
		
		
	}
	
	

}
