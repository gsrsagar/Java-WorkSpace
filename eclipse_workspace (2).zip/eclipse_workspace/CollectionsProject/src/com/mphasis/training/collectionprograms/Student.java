package com.mphasis.training.collectionprograms;

public class Student implements Comparable<Student> {
	 private long Sid;
	 private String Sname;
	 private int Marks; 
	 private int Age;
	public long getSid() {
		return Sid;
	}
	public void setSid(long sid) {
		Sid = sid;
	}
	public String getSname() {
		return Sname;
	}
	public void setSname(String sname) {
		Sname = sname;
	}
	public long getMarks() {
		return Marks;
	}
	public void setMarks(int marks) {
		Marks = marks;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public Student(long sid, String sname, int marks, int age) {
		super();
		Sid = sid;
	 Sname = sname;
		Marks = marks;
		Age = age;
	}
  public Student()
  {
  }
@Override
public int compareTo(Student s1) {
	 if(Sid > s1.getSid())
	return 1;
	 else if(Sid< s1.getSid())
	 return -1;
	 else
		return 0;
}

  
  
  
  }
	 	


