
package com.mphasis.training.collectionprograms;


import java.util.*;

public class ListDemo {
	public static void main(String args[]) {
		
		List<Integer> l1=new ArrayList<>();
		List<Integer> l2=new ArrayList<>();
		l1.add(123);
		l1.add(4567);
		l1.add(44);
		l1.add(47);
		l1.add(244247);
		
		//l1.add("sagar");
		l2.addAll(l1);
		Collections.sort(l2);
		System.out.println("Afet sort");
		System.out.println(l2);
		System.out.println(l1);
		System.out.println(l1);
		System.out.println("based on index"+l1.get(2));
		
		List<Employee> employees=new ArrayList<>();
		employees.add(new Employee(12,"sagar","AP"));
		employees.add(new Employee(13,"padma","TL"));
		employees.add(new Employee(14,"Vinutha","KA"));
		employees.add(new Employee(15,"Afshaan","AP"));
		employees.add(new Employee(16,"Rohith","AP"));
		employees.add(new Employee(17,"Supragna","AP"));
		employees.add(new Employee(18,"Bhuma","AP"));
		employees.add(new Employee(19," VenkatSubbarao","AP"));
		employees.add(new Employee(20,"ravi kiran","AP"));
		
		
		System.out.println("------------------------------");
		System.out.println(employees);
		System.out.println("------------------------------");
		
		//enhanced version of the for loop
		for(Employee e:employees)
		{
			 System.out.println(e.getEmpid()+" "+e.getEname());
		}
		System.out.println("------------------------------");
		
		//one direction iterator
		Iterator<Employee> it=employees.iterator();
		while(it.hasNext())
		{
			 Employee e1=it.next();
		System.out.println(e1.getEmpid()+" "+e1.getEname());
		}
		System.out.println("------------------------------");
		
		//bi direction
		
		ListIterator<Employee> lit=employees.listIterator();
		while(lit.hasNext())
		{   Employee e1=lit.next();
			System.out.println(e1.getEmpid()+" "+e1.getEname());
		}
		System.out.println("--------------------------------");
		System.out.println("Last to first");
		ListIterator<Employee> lit1=employees.listIterator(9);
		 while(lit1.hasPrevious())
		 {
			 Employee e1=lit1.previous();
			 System.out.println(e1.getEmpid()+" "+e1.getEname());
		 }
		 
		 System.out.println("---------------legacy----------");
		Vector v1=new Vector();
		v1.add(new Employee(13,"atul","MP"));
		Enumeration en=v1.elements();
		while(en.hasMoreElements())
		{
			 Employee e=(Employee)en.nextElement();
			 System.out.println(e.getEname());
		}
		
		System.out.println("Employees sort");
		Collections.sort(employees);
		for(Employee e:employees)
		{ 
		  System.out.println(e.getEmpid()+" "+e.getEname());
		}
		
		// till java 7
		Comparator<Employee> eCom=new Comparator<Employee>()
				{
		@Override
		public  int compare(Employee o1,Employee o2) {
			 // todo auto-generated methos sub
			return o1.getAddress().compareTo(o2.getAddress());
		}
		
 };
 
   // in java 8 with lamda
    Comparator<Employee>  eCom1=(Employee o1,Employee o2)-> 
    {  return o1.getAddress().compareTo(o2.getAddress());
    
    };
    
    //in java 8 with method reference
    
    Comparator<Employee> eCom2= Comparator.comparing(Employee::getEname);
   
 
 
   System.out.println("employee sort based on names");
   Collections.sort(employees, new  ComparatorName());
     for(Employee e:employees)
     {
    	 System.out.println(e.getEmpid()+" "+e.getEname());
     }
     
     System.out.println("-------------------------------");
     System.out.println("based on address");
     Collections.sort(employees,eCom);
     for(Employee e:employees)
     {
    	 System.out.println(e.getEmpid()+" "+e.getEname());
     }
 
     System.out.println("--------------------------------");
      //one direction
     
    		
		
	}
	

}









