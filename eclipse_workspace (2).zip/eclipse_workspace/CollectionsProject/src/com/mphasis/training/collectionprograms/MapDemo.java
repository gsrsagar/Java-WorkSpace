package com.mphasis.training.collectionprograms;

import java.util.*;
public class MapDemo {
	
      public static void main(String args[])
      {
    	   Map<Integer, String> m1=new TreeMap<>();
    	   m1.put(120, "Supragna");
    	   m1.put(121, "Haripruiya");
    	   System.out.println(m1);
    	   
    	   Map<Integer, Employee> m2=new TreeMap<>();
    	   m2.put(120, new Employee(1,"riya","AP"));
    	   m2.put(121, new Employee(2,"Sriram","AP"));
    	   m2.put(122, new Employee(3,"rohit","AP"));
    	   m2.put(123, new Employee(4,"Paddu","TL"));
    	   m2.put(124, new Employee(5,"Subbarao","AP"));
    	   m2.put(125, new Employee(6,"Vinutha","KA"));
    	    System.out.println(m2);
    	    
    	    
    	   Map<Question, List<Answer>> em=new TreeMap<Question,List<Answer>>();
    	   List<Answer> la=new ArrayList<Answer>();
    	   
    	     la.add(new Answer("first answer","Second answer","third answer","forth anser"));
    	     la.add(new Answer("first answer","Second answer","third answer","forth anser"));
    	     la.add(new Answer("first answer","Second answer","third answer","forth anser"));
    	     la.add(new Answer("first answer","Second answer","third answer","forth anser"));
    	     
    	    em.put(new Question("1"),la);
    	    em.put(new Question("2"), la);
    	    em.put(new Question("3"), la);
    	    em.put(new Question("4"), la);
    	    System.out.println("Fetching Keys and corresponding [Multiple] Values n");
            for (Map.Entry<Question, List<Answer>> entry : em.entrySet())
            {
                Question key = entry.getKey();
                System.out.println(key.getQues());
                
                for(Answer a:la)
                {
                
                List<Answer> values = entry.getValue();
               
                System.out.println(a.getAnswer1()+" , "+a.getAnswer2()+", "+a.getAnswer3()+" ,"+a.getAnswer4());
    	    
            }   
            
      }
      }
}
